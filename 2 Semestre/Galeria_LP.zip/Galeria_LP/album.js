document.addEventListener("DOMContentLoaded", function () {
    const albumDiv = document.getElementById('album');
    const parametrosDiv = document.getElementById('parametros');
    const playButton = document.getElementById('play');
    const nextButton = document.getElementById('next');
    const prevButton = document.getElementById('previous');
    const topButton = document.getElementById('top');
    const resetButton = document.getElementById('reset');

    const prefixoAlbumInput = document.getElementById('prefixoAlbum');
    const numeroAlbumInput = document.getElementById('numeroAlbum');
    const numeroFotoInicialInput = document.getElementById('numeroFotoInicial');
    const quantidadeFotosInput = document.getElementById('quantidadeFotos');
    const larguraFotosSelect = document.getElementById('larguraFotos');
    const extensaoImagemSelect = document.getElementById('extensaoImagem');

    const verificarImagem = (url) => {
        return new Promise((resolve) => {
            const img = new Image();
            img.onload = () => resolve(true);
            img.onerror = () => resolve(false);
            img.src = url;
        });
    };

    const adicionarTranslucidez = () => {
        if (nextButton.disabled) {
            nextButton.classList.add('translucido');
        } else {
            nextButton.classList.remove('translucido');
        }
    };

    const atualizarAlbum = async () => {
        albumDiv.innerHTML = '';

        const prefixoAlbum = prefixoAlbumInput.value;
        const numeroAlbum = numeroAlbumInput.value;
        const numeroFotoInicial = parseInt(numeroFotoInicialInput.value);
        const quantidadeFotos = parseInt(quantidadeFotosInput.value);
        const larguraFotos = larguraFotosSelect.value;
        const extensaoImagem = extensaoImagemSelect.value;

        let var_buscando_qt = 0;
        let var_encontrou_qt = 0;
        let var_nao_encontrou_qt = 0;
        let var_ultima_nr = numeroFotoInicial;

        for (let i = numeroFotoInicial; var_encontrou_qt < quantidadeFotos && var_nao_encontrou_qt < 20; i++) {
            const imageUrl = `imagens/${prefixoAlbum}${numeroAlbum.padStart(3, '0')}_${String(i).padStart(5, '0')}.${extensaoImagem}`;
            const imagemExiste = await verificarImagem(imageUrl);

            if (imagemExiste) {
                var_encontrou_qt++;
                var_ultima_nr = i;

                const photoDiv = document.createElement('div');
                photoDiv.classList.add('photo');
                photoDiv.style.width = larguraFotos;
                const img = document.createElement('img');
                img.src = imageUrl;
                img.addEventListener('click', () => {
                    if (photoDiv.style.width === larguraFotosSelect.value) {
                        photoDiv.style.width = '98vw';
                    } else {
                        photoDiv.style.width = larguraFotosSelect.value;
                    }
                });
                photoDiv.appendChild(img);
                albumDiv.appendChild(photoDiv);
            } else {
                var_nao_encontrou_qt++;
            }

            var_buscando_qt++;
        }

        nextButton.disabled = var_nao_encontrou_qt >= 20;

        adicionarTranslucidez();

        localStorage.setItem('prefixoAlbum', prefixoAlbum);
        localStorage.setItem('numeroAlbum', numeroAlbum);
        localStorage.setItem('numeroFotoInicial', numeroFotoInicial);
        localStorage.setItem('quantidadeFotos', quantidadeFotos);
        localStorage.setItem('larguraFotos', larguraFotos);
        localStorage.setItem('extensaoImagem', extensaoImagem);
        localStorage.setItem('var_ultima_nr', var_ultima_nr);
    };

    const verificarLocalStorage = () => {
        if (localStorage.getItem('prefixoAlbum')) {
            prefixoAlbumInput.value = localStorage.getItem('prefixoAlbum');
        }
        if (localStorage.getItem('numeroAlbum')) {
            numeroAlbumInput.value = localStorage.getItem('numeroAlbum');
        }
        if (localStorage.getItem('numeroFotoInicial')) {
            numeroFotoInicialInput.value = localStorage.getItem('numeroFotoInicial');
        }
        if (localStorage.getItem('quantidadeFotos')) {
            quantidadeFotosInput.value = localStorage.getItem('quantidadeFotos');
        }
        if (localStorage.getItem('larguraFotos')) {
            larguraFotosSelect.value = localStorage.getItem('larguraFotos');
        }
        if (localStorage.getItem('extensaoImagem')) {
            extensaoImagemSelect.value = localStorage.getItem('extensaoImagem');
        }
    };

    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    };

    const resetPage = () => {
        localStorage.clear();
        window.location.reload();
    };

    [prefixoAlbumInput, numeroAlbumInput, numeroFotoInicialInput, quantidadeFotosInput, larguraFotosSelect, extensaoImagemSelect].forEach(input => {
        input.addEventListener('change', () => {
        });
    });

    const alterarTemaButton = document.getElementById('alterarTema');
    alterarTemaButton.addEventListener('click', () => {
        document.body.classList.toggle('dark-theme');
    });

    playButton.addEventListener('click', atualizarAlbum);

    nextButton.addEventListener('click', () => {
        const ultimaFotoNr = parseInt(localStorage.getItem('var_ultima_nr') || numeroFotoInicialInput.value);
        numeroFotoInicialInput.value = ultimaFotoNr + 1;
    });

    prevButton.addEventListener('click', () => {
        let novoNumeroFotoInicial = parseInt(numeroFotoInicialInput.value) - parseInt(quantidadeFotosInput.value);
        if (novoNumeroFotoInicial < 1) {
            novoNumeroFotoInicial = 1;
        }
        numeroFotoInicialInput.value = novoNumeroFotoInicial;
    });

    topButton.addEventListener('click', scrollToTop);
    resetButton.addEventListener('click', resetPage);

    verificarLocalStorage();
});