#include <stdio.h>

int main()
{
    myFunction();
    return 0;
}

void myFunction()
{
    printf("Hello, I am a Function\n");
}
