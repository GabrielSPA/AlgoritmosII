#include <stdio.h>

int main() {
    int numeros[] = {39, 45, 55};
    printf("%d", numeros[2]);

    return 0;
}
