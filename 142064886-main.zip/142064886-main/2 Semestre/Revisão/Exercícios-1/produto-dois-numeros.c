#include <stdio.h>

int main() {

    int a, b, p;

    printf("Digite o primeiro número: ");
    scanf("%d", &a);

    printf("Digite o segundo número: ");
    scanf("%d", &b);

    p = a * b;

    printf("O produto é: %d\n", p);

    return 0;
}
