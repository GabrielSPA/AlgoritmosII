#include <stdio.h>

int main() {

    int a, b, s;

    printf("Digite o primeiro número: ");
    scanf("%d", &a);

    printf("Digite o segundo número: ");
    scanf("%d", &b);

    s = a * b;

    printf("A soma é: %d\n", s);

    return 0;
}
