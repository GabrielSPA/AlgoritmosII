#include <stdio.h>

int main() {

    printf("Este é um programa em\nC.");

    printf("Este\né\num\nprograma\nem\nC.");

    return 0;
}
