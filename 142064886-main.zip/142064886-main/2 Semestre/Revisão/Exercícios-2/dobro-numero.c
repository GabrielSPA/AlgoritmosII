#include <stdio.h>

int main() {

    int x, dobro;

    printf("Digite um valor para X: ");
    scanf("%i", &x);

    dobro = x * 2;

    printf("O dobro do valor digitado é: %i", dobro);

    return 0;
    }
