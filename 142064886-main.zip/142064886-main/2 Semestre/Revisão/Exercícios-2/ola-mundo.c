#include <stdio.h>

int main() {

    printf("Olá Mundo!")

    return 0;
}
