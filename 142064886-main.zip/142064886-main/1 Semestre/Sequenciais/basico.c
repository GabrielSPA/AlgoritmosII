#include <stdio.h>

int main (){
    int A, B, X;

    scanf("%i", &A);

    scanf("%i", &B);

    X = A + B;

    printf("X = %i\n", X);

    return 0;
}