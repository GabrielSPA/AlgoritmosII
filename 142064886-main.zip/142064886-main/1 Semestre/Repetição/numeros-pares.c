#include <stdio.h>

int main() {

    int par = 2;

    while (par <= 100 ){

        printf("%d\n", par);
        par += 2;

    }

    return 0;
}