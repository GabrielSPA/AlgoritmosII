#include <stdio.h>

int main() {

    int X, Y, i, total = 0, total2 = 0;

    scanf("%d%d", &X,&Y);

    if (X > Y) {
        for (i = Y; i <= X; i++) {
            if (i % 13 != 0) {
                total += i;
            }
        }
        printf("%d\n", total);
    }
    else if(X < Y){
        for (i = X; i <= Y; i++) {
            if (i % 13 != 0) {
                total2 +=i;
            }
        }
        printf("%d\n", total2);
    }
   return 0;
}