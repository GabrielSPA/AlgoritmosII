#include <stdio.h>

int main() {

    int x;

    scanf("%i");

    if ("%i" == 0){
        printf ("NULL");
    }

    return 0;

    }